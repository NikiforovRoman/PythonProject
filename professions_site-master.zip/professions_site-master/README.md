# professions_site

# Запуск:
1. python -m venv venv
2. cd venv/Scripts/
3. activate
4. cd ../..
5. pip install -r requirements.txt
6. python manage.py migrate
7. python manage.py runserver

# Создать юзера:
python manage.py createsuperuser
